
const bird = document.getElementById('bird');
const pipe = document.getElementById('pipe');
const pipeTop = document.getElementById('pipe-top');
const scoreboard = document.getElementById('scoreboard');
const gameContainer = document.getElementById('game-container');

let birdTop = 200;
let gravity = 2;
let isGameOver = false;
let pipePosition = 400;
let score = 0;
let rainbowMode = false;

// Listen for key events
document.addEventListener('keydown', jump);
document.addEventListener('keydown', enableRainbowMode);

function jump() {
  if (!isGameOver) birdTop -= 40;
}

function enableRainbowMode(e) {
  if (e.key === '1') {
    document.addEventListener('keydown', (event) => {
      if (event.key === '2') {
        rainbowMode = true;
      }
    });
  }
}

function gameLoop() {
  if (isGameOver) return;

  // Apply gravity
  birdTop += gravity;
  bird.style.top = birdTop + 'px';

  // Move pipes
  pipePosition -= 3;
  if (pipePosition < -60) {
    pipePosition = 400;
    // Randomize pipe gap
    const pipeHeight = Math.random() * 150 + 100;
    pipe.style.height = `${pipeHeight}px`;
    pipeTop.style.height = `${600 - pipeHeight - 150}px`;

    // Increment score when the bird passes the pipe
    score++;
    scoreboard.textContent = `Score: ${score}`;
  }
  pipe.style.left = pipePosition + 'px';
  pipeTop.style.left = pipePosition + 'px';

  // Rainbow mode effect
  if (rainbowMode) {
    bird.style.backgroundColor = `hsl(${Math.random() * 360}, 100%, 50%)`;
  }

  // Collision detection
  if (
    birdTop < 0 || 
    birdTop > 570 || 
    (pipePosition < 80 && pipePosition > 50 &&
     (birdTop < 600 - parseFloat(pipeTop.style.height) - 150 || birdTop > 600 - parseFloat(pipe.style.height)))
  ) {
    isGameOver = true;
    alert(`Game Over! Your score is: ${score}`);
  }

  requestAnimationFrame(gameLoop);
}

// Start the game
gameLoop();
